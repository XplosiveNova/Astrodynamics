function [CL, CL_Alpha, CD, CDo, CDi, K] = transonic_aero_model(Mach, AOA, G)

    format long
    clc;
    currentFolder = fileparts(mfilename('fullpath'));
    HW3Path = fullfile(currentFolder, '..', 'HW3 CL FUNCTIONS');
    addpath(HW3Path);

    [CL, CL_Alpha] = compute_transonic_CL(Mach, AOA, G);

    [CD, CDo, CDi, K] = compute_transonic_CD(CL, Mach, G);

end