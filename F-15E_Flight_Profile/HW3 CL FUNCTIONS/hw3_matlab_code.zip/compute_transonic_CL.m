function [CL, CL_alpha] = compute_transonic_CL(M, AOA, G)

    format long

    AOA = AOA * pi / 180;   % [rad] Angle of Attack
    G.SW = G.SW * pi / 180; % [rad] LE Sweep Angle
    G.Iw = G.Iw * pi / 180; % [rad] Incidence Angle of Wing
    G.A0 = G.A0 * pi / 180; % [rad] Zero-Lift AOA
    
    M_CR = 0.9;
    M_SS = 1.3;

    M_MID = 1.1; 
    % [] Mach Number at Highest CL_Alpha

    if M <= M_MID

        [CL, CL_alpha_crit] = compute_subsonic_CL(M_CR, AOA, G);
        [a, b, c] = find_parabola_with_curvature(.9, .078, 1.1, .087, 0.1);

        CL_alpha = a*M^2 + b*M + c + CL_alpha_crit;
        % [rad^-1] Interpolated Transonic Lift Curve Slope

    else
        
        [CL, CL_alpha_crit] = compute_supersonic_CL(M_SS, AOA, G);
        [a, b, c] = find_parabola_with_curvature(1, .08, 1.3, .07, -0.1);
        
        CL_alpha = a*M^2 + b*M + c  + CL_alpha_crit;
        % [rad^-1] Interpolated Transonic Lift Curve Slope

    end
    
    CL = CL_alpha * (AOA + G.Iw - G.A0);
    % [] Transonic Compressible Lift Coefficient

end