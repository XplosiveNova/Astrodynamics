format long; close all; clc; clear;

[G, trajS, propS] = cruise_constants();

[x, t, Vcruise, p, h, W, POWERV, xi, dxdtV, dwdtV, dpdtV, ...
dhdtV, gammaV, LV, DV, LODV, TV, Treq_totV, Treq_engV, SV, MachV, aV] = simulate_constant_velocity_constant_CL_cruise_climb(trajS, propS, G);

figure(1)
plot_trajectory_variable(x, h, "Range", "Altitude", [0 1000], [35, 50], "", "")
figure(2)
plot_trajectory_variable(MachV, H, "Mach Number", "Altitude", "", "", "", "")
figure(3)
plot_trajectory_variable(t, h, "Time", "Altitude", "", "", "", "")
figure(4)
plot_trajectory_variable(t, x, "Time", "L/D", "", "", "", "")
figure(5)
plot_trajectory_variable(x, W, "Range", "Weight", "", "", "", "")
figure(6)
plot_trajectory_variable(t, gammaV, "Time", "Flight Path Angle", "", "", "", "")
figure(7)
plot_trajectory_variable(t, POWERV, "Time", "Power", "", "", "", "")
figure(8)
plot_trajectory_variable(t, SV, "Time", "SFC", "", "", "", "")
figure(9)
plot_trajectory_variable(t, Treq_engV, "Time", "Treq", "", "", "")
figure(10)
plot_trajectory_variable(t, TV, "Time", "Thrust CUrrent", "", "", "", "")
figure(11)
plot_trajectory_variable(t, Treq_totV, "Time", "Ttot", "", "", "", "")


