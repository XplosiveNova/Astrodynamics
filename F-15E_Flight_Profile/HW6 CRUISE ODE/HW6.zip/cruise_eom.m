function dydt = cruise_eom(t, y, Vcruise, Rcruise, AOAcruise, G, propS)

format long

currentFolder = fileparts(mfilename('fullpath'));
HW1Path = fullfile(currentFolder, '..', 'HW1 ATM MODEL');
addpath(HW1Path);
HW4Path = fullfile(currentFolder, '..', 'HW4 F15 PERFORMANCE');
addpath(HW4Path);
HW5Path = fullfile(currentFolder, '..', 'HW5 ENGINE DESIGN');
addpath(HW5Path);

x = y(1);
p = y(2);
alt = y(3);
W = y(4);

[~, Tinf, Pinf, ~] = atm_model(alt, G.units);
[~, Mach, Q, ~] = flight_condition(alt, Vcruise , "", G.units);

[~, D, CL, ~, ~, ~, ~, ~] = aero_conflict_func(...
    Mach, AOAcruise, Q, G);

Treq = D / cosd(AOAcruise + G.ep0);
Treq_eng = Treq / G.N_eng;

POWER_guess = 0.8;
POWER = fzero(@(POWER) throttle_solve(POWER, Treq_eng, Mach, alt, G, propS), POWER_guess);

propOut = compute_offdesign_ideal_AB_TJ_performance(Mach, alt, POWER, G.units, propS.ABswitch, propS);
T_eng = propOut.F;
SFC = propOut.S/3600;

dxdt = Vcruise;
dWdt = -SFC * T_eng * G.N_eng;
dpdt = (2 * propS.R * Tinf) / (Vcruise^2 * CL * G.S) * dWdt;
dpdh = -propS.g0 * Pinf / (propS.R * Tinf);
dhdt = dpdt / dpdh;

dydt = [dxdt; dpdt; dhdt; dwdt];

end