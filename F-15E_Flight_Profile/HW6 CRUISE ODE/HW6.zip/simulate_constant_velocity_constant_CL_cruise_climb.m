function [x, t, Vcruise, p, h, W, POWERV, xi, dxdtV, dwdtV, dpdtV, ...
          dhdtV, gammaV, LV, DV, LODV, TV, Treq_totV, Treq_engV, SV, MachV, aV] = simulate_constant_velocity_constant_CL_cruise_climb(trajS, propS, G)

format long

currentFolder = fileparts(mfilename('fullpath'));
HW1Path = fullfile(currentFolder, '..', 'HW1 ATM MODEL');
addpath(HW1Path);
HW4Path = fullfile(currentFolder, '..', 'HW4 F15 PERFORMANCE');
addpath(HW4Path);
HW5Path = fullfile(currentFolder, '..', 'HW5 ENGINE DESIGN');
addpath(HW5Path);

% Define initial conditions

xi = trajS.xi;
Pi = trajS.PresCruisei;
hi = trajS.hi;
Wi = trajS.Wi;
y0 = [xi;Pi;hi;Wi];
Rcruise = trajS.RangeCruise;
MachCruise = trajS.MachCruise;

[Vi, ~, q, ~] = flight_condition(trajS.hi, "" , MachCruise, G.units);

Vcruise = Vi;
ti = trajS.ti;
tmax = Rcruise * 6076.12/Vcruise + 20*60;
t_span = [ti, ti + tmax];

% Solve for alphaCruise

alpha_guess = 1; % degrees
alphaCruise = fzero(@(alpha) aoa_solve(alpha, Wi, MachCruise, q, G), alpha_guess);

% Integrate functions

opts = odeset('Events', @(t, y) terminate_range(t, y, Vcruise, Rcruise, alphaCruise, G, propS));
[t, Y] = ode45(@(t, y) cruise_eom(t, y, Vcruise, Rcruise, alphaCruise, G, propS), t_span, y0, opts);

% Now you have output vectors for x, p, h, W, and t
xV = Y(:, 1);
pV = Y(:, 2);
hV = Y(:, 3);
WV = Y(:, 4);
tV = t;
% Now, you need to generate the rest of the trajectory variable vectors. You can do this by looping
% back through the integration EOM step by step. You can follow the following template:

% Don’t forget to preallocate your output vectors
for i = 1:length(tV)
    x = xV(i);
    p = pV(i);
    h = hV(i);
    W = WV(i);
end

% Call flight condition function

fltConOut = atm_model(h, "EN");
Tinf = fltConOut.T;
fltConOut = flight_condition(h, Vcruise , "" , G.units);
q = fltConOut.q;
Mach = fltConOut.M;
R = propS.R;
g0 = propS.g0;
a = fltConOut.a;

% Call aerodynamics conflict function

AEROoutputs = aero_conflict_func(alphaCruise, Mach, q, G);
CL = AEROoutputs.CL;
D = AEROoutputs.D;
L = AEROoutputs.L;

Treq_tot = D / cosd(alphaCruise + G.ep0);
Treq_eng = Treq_tot / G.N_eng;

% Solve for throttle to match thrust to drag
POWER_guess = 0.8;
POWER = fzero(@(POWER) throttle_solve(POWER, Treq_eng, Mach, h, G.units, propS), POWER_guess);

% Get available thrust (throttle setting P = 1 for Tavail)
propOut = compute_offdesign_ideal_AB_TJ_performance(Mach, h, 1, G.units,propS.ABswitch, propS);
Tavail = propOut.F;

% Calculate thrust and specific fuel consumption (SFC) at the current throttle setting
propOut = compute_offdesign_ideal_AB_TJ_performance(Mach,h,POWER,G.units,propS.ABswitch, propS);
T = propOut.F;          % Uninstalled thrust per engine
S = propOut.S / 3600;   % (lbm/sec/lbf) uninstalled SFC per engine

% Equations of Motion (from page 67 in Miele)

dxdt = Vcruise;
dwdt = -S * T * G.N_eng;
dpdt = (2 * R * Tinf * dwdt) / (Vcruise^2 * CL * G.S);
dhdt = dpdt / (-g0 * p / (R * Tinf));
gamma = (dhdt / Vcruise) * (180 / pi);

% EOM in Vector State

POWERV = zeros(length(tV), 1);
aV = zeros(length(tV), 1);
dxdtV = zeros(length(tV), 1);
dwdtV = zeros(length(tV), 1);
dpdtV = dpdt;
dhdtV = zeros(length(tV), 1);
gammaV = zeros(length(tV), 1);
LV = zeros(length(tV), 1);
DV = zeros(length(tV), 1);
LODV = zeros(length(tV), 1);
TV = zeros(length(tV), 1);
Treq_engV = zeros(length(tV), 1);
Treq_totV = zeros(length(tV), 1);
TavailV = zeros(length(tV), 1);
SV = zeros(length(tV), 1);
IspV = zeros(length(tV), 1);
MachV = zeros(length(tV), 1);

for i = 1:length(tV)
    POWERV(i) = POWER;
    aV(i) = T * cosd(alphaCruise + G.ep0) - D;
    dxdtV(i) = dxdt;
    dwdtV(i) = dwdt;
    dpdtV(i) = dpdt;
    dhdtV(i) = dhdt;
    gammaV(i) = gamma;
    LV(i) = L;
    DV(i) = D;
    LODV(i) = L / D;
    TV(i) = T;
    Treq_engV(i) = Treq_eng;
    Treq_totV(i) = Treq_tot;
    TavailV(i) = Tavail;
    SV(i) = S * 3600; % SFC in lbm/hr/lbf
    IspV(i) = 3600 / S; % Specific Impulse (sec)
    MachV(i) = Vcruise / a; % Mach number
end

end