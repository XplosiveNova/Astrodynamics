function [error] = throttle_solve(POWER, Treq_eng, Mach_inf, alt, units, propS)

format long

currentFolder = fileparts(mfilename('fullpath'));
HW5Path = fullfile(currentFolder, '..', 'HW5 ENGINE DESIGN');
addpath(HW5Path);

propOut = compute_offdesign_ideal_AB_TJ_performance(Mach_inf,alt,POWER, units, propS.ABswitch, propS);
Tcurrent = propOut.F;
error = Tcurrent - Treq_eng;

end