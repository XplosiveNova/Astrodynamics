function [error] = aoa_solve(AOA, W, Mach_inf, Q_inf, G)

format long

currentFolder = fileparts(mfilename('fullpath'));
HW4Path = fullfile(currentFolder, '..', 'HW4 F15 PERFORMANCE');
addpath(HW4Path);

aeroOutputs = aero_conflict_func(AOA, Mach_inf, Q_inf, G);
L = aeroOutputs.L;
error = L - W;

end