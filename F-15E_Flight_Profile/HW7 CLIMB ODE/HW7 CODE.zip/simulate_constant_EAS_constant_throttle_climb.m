function [x, t, V, p, h, W, POWERV, aV, anV, dxdtV, dwdtV, ...
          dhdtV, dVdtV, dfpadtV, dsigmadhV, dVdhV, fpaV, ... 
          LV, DV, LODV, TcurV, TavaV, Treq_totV, SV, MachV, AOAV, qV] = simulate_constant_EAS_constant_throttle_climb(trajS, propS, G)

format long

% Define initial conditions

ep0 = G.ep0;
Neng = G.N_eng;

hcruise = trajS.hcruise;
Powerclimb = trajS.Powerclimb;
Vcruise = trajS.Vcruise;

R = propS.R;
g0 = propS.g0;
T0 = trajS.T0;
P0 = trajS.P0;
Rho0 = (P0/(R*T0));

xi = trajS.xi;
hi = trajS.hi;
Vi = trajS.Vi;
Wi = trajS.Wi;
fpai = trajS.fpai;
y0 = [xi;hi;Vi; Wi; fpai];

ti = trajS.ti;
tmax = 5000;
tspan = [ti, ti + tmax];

% Integrate functions

opts = odeset('RelTol', 1e-6, 'AbsTol', 1e-6, 'Events', @(t, y) terminate_climb(t, y, Powerclimb, hcruise, G, propS));

[t, Y] = ode45(@(t, y) climb_eom(t, y, Powerclimb, hcruise, G, propS), tspan, y0, opts);

% Now you have output vectors for x, h, V, W, and FPA
xV = Y(:, 1);
hV = Y(:, 2);
VV = Y(:, 3);
WV = Y(:, 4);
fpaV = Y(:, 5);
tV = t;

% EOM in Vector State

p = zeros(length(tV), 1);
POWERV = zeros(length(tV), 1);
aV = zeros(length(tV), 1);
anV = zeros(length(tV), 1);
dVdtV = zeros(length(tV), 1);
dxdtV = zeros(length(tV), 1);
dwdtV = zeros(length(tV), 1);
dhdtV = zeros(length(tV), 1);
dfpadtV = zeros(length(tV), 1);
dsigmadhV = zeros(length(tV), 1);
dVdhV = zeros(length(tV), 1);
LV = zeros(length(tV), 1);
DV = zeros(length(tV), 1);
LODV = zeros(length(tV), 1);
TcurV = zeros(length(tV), 1);
Treq_engV = zeros(length(tV), 1);
Treq_totV = zeros(length(tV), 1);
TavaV = zeros(length(tV), 1);
SV = zeros(length(tV), 1);
IspV = zeros(length(tV), 1);
MachV = zeros(length(tV), 1);
AOAV = zeros(length(tV), 1);
qV = zeros(length(tV), 1);

% Don’t forget to preallocate your output vectors
for i = 1:length(tV)
    x = xV(i);
    h = hV(i);
    V = VV(i);
    W = WV(i);
    fpa = fpaV(i);

    % Call flight condition function
    
    [~, Tinf, ~, Rhoinf] = atm_model(h, "EN");
    theta = Tinf/T0;
    sigma = Rhoinf/Rho0;
    
    [Mach, ~, ~, ~] = flight_condition(h, Vcruise , "" , G.units);
    q = 881;
    a = sqrt(propS.gamma * R * Tinf);
    
    Veas = sqrt(2*q/Rho0);
    
    % Get available thrust (throttle setting P = 1 for Tavail)
    [~, Tava, ~, ~, ~, ~, ~] = compute_offdesign_ideal_AB_TJ_performance(Mach, h, 1, G.units,propS.ABswitch, propS);
    
    % Calculate thrust and specific fuel consumption (SFC) at the current throttle setting
    [~, T_eng, S, ~, ~, ~, ~] = compute_offdesign_ideal_AB_TJ_performance(Mach,h,Powerclimb,G.units,propS.ABswitch, propS);  % Uninstalled thrust per engine
    T = T_eng * Neng;
    S = S / 3600;   % (lbm/sec/lbf) uninstalled SFC per engine

    if h < 36089 && h >= 0
        Ti_prime = (-6.5/1000)*1.8/3.28083; % R/ft 
        dsigmadh = (-g0/(R*Ti_prime) -1) * theta^(-g0/(R*Ti_prime) - 2) * (Ti_prime/T0);
    elseif h >= 36089 && h < 65617
        Ti = 216.65*(9/5); % Rankine
        Pi = 22636.049*0.020885; % lbf/ft^2
        zi = 11000 * 3.28083; % ft
        z = RE*h/(RE+h); % geopotential altitude equation
        dsigmadh = (Pi/(R*Ti*rho_o)) * exp(-g0*(z-zi)/(R*Ti)) * (-g0/(R*Ti)) * ((RE^2)/((RE+h)^2));
    else
        return;
    end
    
    % Equations of Motion (from page 67 in Miele)
    
    dVdh =  - Veas/(2*sigma^1.5) * dsigmadh;
    dhdt = V * sin(fpa);
    dVdt = dVdh * dhdt;
    
    % Call aerodynamics conflict function
    
    aoa_guess = 4;
    aoa = fsolve(@(aoa) aoa_solve(aoa,W,fpa,dVdt,Mach,q, T_eng, G), aoa_guess);

    if Mach < 0
        break
    end
    
    [L, D, ~, ~, ~, ~, ~, ~]  = aero_conflict_func(aoa, Mach, q, G);
    Treq_tot = (D + W*sin(fpa)) / cosd(aoa + ep0);
    Treq_eng = Treq_tot/Neng;
    
    dfpadt = g0/ (W * V) * (T * sind(aoa + ep0) + L - W*cos(fpa));
    dxdt = V * cos(fpa);
    dWdt = -S * T;

    POWERV(i) = Powerclimb;
    aV(i) = ((T * cosd(aoa + ep0)) - D - W*sin(fpa)) / W;
    anV(i) = V*dfpadt/g0;
    dVdtV(i) = dVdt;
    dxdtV(i) = dxdt;
    dwdtV(i) = dWdt;
    dhdtV(i) = dhdt;
    dfpadtV(i) = dfpadt;
    dsigmadhV(i) = dsigmadh;
    dVdhV(i) = dVdh;
    LV(i) = L;
    DV(i) = D;
    LODV(i) = L/D;
    TcurV(i) = T;
    Treq_engV(i) = Treq_eng;
    Treq_totV(i) = Treq_tot;
    TavaV(i) = Tava;
    SV(i) = S*3600;             % SFC in lbm/hr/lbf
    IspV(i) = 3600 / S; 
    MachV(i) = V / a; 
    AOAV(i) = aoa;
    qV = q;

end

end