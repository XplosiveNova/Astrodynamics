function [error] = aoa_solve(AOA, W, fpa, dVdt, Mach_inf, Q_inf, T, G)

format long

g0 = 32.17;
[~, D, ~, ~, ~, ~, ~, ~] = aero_conflict_func(Mach_inf, AOA, Q_inf, G);
error = T * G.N_eng * cosd(AOA + G.ep0) - D - W*sin(fpa) - dVdt * W / g0;

end