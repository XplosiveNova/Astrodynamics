function dydt = climb_eom(t, y, Pclimb, hcruise, G, propS)

format long

x = y(1);
h = y(2);
V = y(3);
W = y(4);
fpa = y(5);

g0 = propS.g0;

R = propS.R;
RE = 20855532; % [ft]

[Machinf, ~, Qinf, ~] = flight_condition(h, V , "", G.units);
[~, To, ~, rho_o] = atm_model(0, G.units);
[~, T, ~, rho] = atm_model(h, G.units);
theta = T/To;
sigma = rho/rho_o;

Veas = sqrt(2 * Qinf / rho_o);

[~, F, S, ~, ~, ~, ~] = compute_offdesign_ideal_AB_TJ_performance(Machinf, h, Pclimb, G.units, propS.ABswitch, propS);
SFC = S/3600;

if h < 36089 && h >= 0
    Ti_prime = (-6.5/1000)*1.8/3.28083; % R/ft 
    dsigmadh = (-g0/(R*Ti_prime) -1) * theta^(-g0/(R*Ti_prime) - 2) * (Ti_prime/To);
elseif h >= 36089 && h < 65617
    Ti = 216.65*(9/5); % Rankine
    Pi = 22636.049*0.020885; % lbf/ft^2
    zi = 11000 * 3.28083; % ft
    z = RE*h/(RE+h); % geopotential altitude equation
    dsigmadh = (Pi/(R*Ti*rho_o)) * exp(-g0*(z-zi)/(R*Ti)) * (-g0/(R*Ti)) * ((RE^2)/((RE+h)^2));
else
    return;
end

dVdh = - Veas/(2*sigma^(1.5)) * dsigmadh;
dhdt = V * sin(fpa);
dVdt = dVdh * dhdt;

alpha_guess = 4;
aoa = fsolve( @(aoa) aoa_solve(aoa, W, fpa, dVdt, Machinf, Qinf, F, G), alpha_guess);

[L, ~, ~, ~, ~, ~, ~, ~] = aero_conflict_func(Machinf, aoa, Qinf, G);

dfpadt = (g0/ (W * V)) * (F * G.N_eng * sind(aoa + G.ep0) + L - W*cos(fpa));
dxdt = V * cos(fpa);
dWdt = -SFC * F * G.N_eng;

dydt = [dxdt; dhdt; dVdt; dWdt; dfpadt];

end